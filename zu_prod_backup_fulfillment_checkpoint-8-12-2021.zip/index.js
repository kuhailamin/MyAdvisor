// See https://github.com/dialogflow/dialogflow-fulfillment-nodejs
// for Dialogflow fulfillment library docs, samples, and to report issues
'use strict';
 
const functions = require('firebase-functions');
const {WebhookClient} = require('dialogflow-fulfillment');
const {BasicCard, Card, Suggestion, Payload} = require('dialogflow-fulfillment');
const firebaseAdmin = require("firebase-admin");
const {dialogflow,Button,Suggestions,Image, Table} = require('actions-on-google');
const app = dialogflow({debug: true});
process.env.DEBUG = 'dialogflow:debug'; // enables lib debugging statements
var Id;





firebaseAdmin.initializeApp({
 databaseURL: 'https://zu-prod-backup-yeov-default-rtdb.firebaseio.com/',
    credential: firebaseAdmin.credential.cert({
        projectId: "zu-prod-backup-yeov",
        clientEmail: "zu-prod-back-up@zu-prod-backup-yeov.iam.gserviceaccount.com",
        privateKey: "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQDZLfHgPg/vw+l3\npdZvuESxnUL21/wGluPviMOybmpE1FY9Y+sLDtqH9errTl5kXSR2xYik70ksv+X3\n7aqnsH37B/or5LWDahFHMcPvjGP/TNV4sw0MpPY2iv2p+311gUVYp+X5hnp8d8gh\nFz/4cG+SN+8tPxKL5tn3+o/yWjOPpEkfXxek0+Lxu3wyTZbDR56XN32orBo/2mEh\n7XatUgJn0CRmMRARRCIgVFKx58icjMpHvu9gQIAUTdv+dku42gwHnA1TywTlZuoD\nfGUgDVyCpp0PzGv1k59m4yIGUkEnrpY3znJ/EFXHiYAmBMg3BOIQWRUV6GT7QTsa\nTMxP18L9AgMBAAECggEADOAZxDQ/DZ/iaiLSy7IeSx60/EgMZkzxG8pSj8mBU1ij\nTuXAPC+X6meR6HwE7JOjuHGNivmvWjp7j8SZ/Bxihky6xXoRqMYpBWeAjjsXJ+jj\niab+fGQV6gs4w/285QfSQfyc4xDYl3h3zOkWnyFLUV0vjicnGlQyp+5FimtT6I1g\nyilLg1mXMTciu4nDeqfumYUfRHHb6iaq4VQ3d8hmgdwO+Anp0mPNa8mMIqLo/z93\n1C0MhyR1qDl7lJcJlBBzc2rB9+a2kIVXD99aBgs4iTY5m++dWX8LrMWi3wLbIG99\nvsj1OG/vGjjCBfr6j3OiagFhKQ2sfqXVQEuvohk7AQKBgQD96zxI3YG9N63AfK31\n4VXID2FqtX6Yjd5a5MzhCoP5jAvPHlNtA3QO9A1IIU3bvup1rme4iqzlMQVwtQKZ\nVzB8MGXxFpoE94KbToLQ/cyl+yOT6HBx6wPDl+Jy8CD6cfUZjbO/Inx/enmrrVqY\nzzsNE7ooXpXrw/yxiryS/CgztQKBgQDa9Z+138JBIJlVRhtjclLrV/mwoN/Sbisi\nAAq+qap6vbpwa6ax4YQu9g2XYQxrlNy5kGjp846Ld/wWuY3SVLPI3XqhmTcTIaSN\n99jF2pJVP7sTM8Dr6WpxyJdJDFO/unjFseuzGBCd7xHVm9PKkTKaog8qlEIecZ+l\ncfvCWIxvKQKBgGacTTxU5z0D5x9GQzZ93SB/tqpctdAIZLbuhyzaBwMtaQhGBQik\nwJ3aWhOwAbqvqCfuVtPoln34FW66d1ZoOZu2IzwOGievrgP88jhql+zrVDFNWUNv\n6ZF9K3GvQGR08MtmzCCNWypY4BpUb6wY8pASTMRLlOI1zUQiAJqVc9mRAoGAPVWM\nlW/GhGPTT9XBmkvN+mq8YMPPrqx5nJ6SY/I29QbskM029qELW/REvmDLD9+1LK3N\nFavKBDtp/BuiJIbhjaSs01ON3+gOpk4FBPdDAmpFxw06P1s1HAZqimXPl+duKUK7\nmYFmNjdfsYxi+V1O5Y373ZuGIe0GIVwaf8g6HnECgYEAhgLFTQrZHA1NmzAOjq/T\nYSdTM5srSN0/JpFp7gcIlZ5hGCF44/RAv9MhdVzpZBOwwXPNJpOR7yp18EwPUWP6\n6/WHB6M8hl3hAXcAWLDOT8jPucTCi68CiHNJYBeHWfD8BkF5eVxweiciqWRMBSwF\nvEz0RXRPXMzPRhsdg9Fdc/c=\n-----END PRIVATE KEY-----\n"
    })
});

exports.dialogflowFirebaseFulfillment = functions.https.onRequest((request, response) => {
  const agent = new WebhookClient({ request, response });
  console.log('Dialogflow Request headers: ' + JSON.stringify(request.headers));
  console.log('Dialogflow Request body: ' + JSON.stringify(request.body));



function RandomResponse(m){
var RR=['How can I improve my GPA?', 'I have some problems with my instructor.',
'I want to change my college.','How can I get to the Dean’s List?','Can I take a senior Project?',
'When can I graduate?','What are the timings of a course?', 'Who teaches a course?', 'Who can help me with internships?' ];
const shuffled = RR.sort(() => 0.5 - Math.random());
let selected = shuffled.slice(0, m);
    const payload = {"richContent":  [
    [
      {
        "type": "chips",
        "options": [
          {
            "text": `${selected[0]}`
	},
	    {
            "text": `${selected[1]}`
	},
	    {
            "text": `${selected[2]}`
	}
        ]
      }
    ]
  ] 
};
return payload; 
}

function favColor(agent){
      agent.add(new BasicCard({
             title: `Title: this is a card title`,
             text: `This is the body texts of a cards.  You can even use line\n  breaks and emoji!`,
        	 buttons: new Button({
             title: `This is a button`,
             url: 'https://assistant.google.com/'
            }),
            image: new Image({
      url: 'https://storage.googleapis.com/actionsresources/logo_assistant_2x_64dp.png',
      alt: 'Image alternate text'
    })
           })
         );
  agent.add(new Suggestion(`Excellent`));
  agent.add(new Suggestion(`Very Good`));
  let speech="<speak><audio src='https://developers.google.com/assistant/downloads/ssml/wavenet-audio.mp3'><desc>a cat purring</desc>PURR (sound didn't load)</audio></speak>";
  agent.add(speech);

}


 

const Seref = firebaseAdmin.database().ref('Section');
const Coref = firebaseAdmin.database().ref('Course');
const Insref = firebaseAdmin.database().ref('Instructor');
  function welcome(agent) {
    agent.add(`Welcome to MyAdvisor! 
                 What is your student ID? `);
  }
 
  function fallback(agent) {
   
    agent.add(`I'm sorry, I didn't understand.Can you try again?\n You can say something like:\n`);
      var payload=RandomResponse(3);
    
      agent.add(
  new Payload(agent.UNSPECIFIED, payload, {rawPayload: true, sendAsMessage: true})
);
  }

 
    function getFromFirebase(agent) {
    return firebaseAdmin.database().ref('address').once("value").then((snapshot) => {
      var address = snapshot.val();
      agent.add(`Hey! The address is ${Id} : ` + address);
    });
  }
  
function StudentInfo(agent){
Id = agent.parameters.ID.toString();
    return firebaseAdmin.database().ref(`Student/${Id}`).once("value").then((snapshot) => {
     //let students = snapshot.val();
     let FName= snapshot.child('FirstName').val();
     let LName= snapshot.child('LastName').val();
    
    if (FName != null || LName !=null){  
      agent.add( `Hello ${FName} ${LName}, here are some examples of how ZUAdvisor can help you:\n ` );
     var payload=RandomResponse(3);
    
      agent.add(
        new Payload(agent.UNSPECIFIED, payload, {rawPayload: true, sendAsMessage: true})
    );
    }
      else {
        agent.add('Sorry, the Student ID you entered is not valid. Please enter a valid Student ID ');
      }
      return Id; 
  });  
    
  }
  
  function BookAppointmentWithAdvisor (agent) {
  var stuID =  agent.parameters.sID.toString();
  var Atext =  agent.parameters.text.toString().toLowerCase();
  var Atopic =  agent.parameters.topic.toString().toLowerCase();
   const timeZone = 'America/Chicago';
const timeZoneOffset = '-06:00';
  const dateTimeStart = new Date(Date.parse(agent.parameters.date.split('T')[0] + 'T' + agent.parameters.time.split('T')[1].split('-')[0] + timeZoneOffset));
   const dateTimeEnd = new Date(new Date(dateTimeStart).setHours(dateTimeStart.getHours() + 1));
   const appointmentTimeString = dateTimeStart.toLocaleString(
     'en-US',
     { month: 'long', day: 'numeric', hour: 'numeric', timeZone: timeZone }
   );
   return firebaseAdmin.database().ref(`Student/${stuID}`).once("value").then((snapshot) => {
       let AdID = snapshot.child('AdvisorID').val().toString(); 
     return firebaseAdmin.database().ref('Instructor').orderByChild('InstructorID').equalTo(AdID).once("value").then((snapshot) => {     
          let instructors = snapshot.val();
          var keys = Object.keys(instructors);
          var InsFname= instructors[keys].InstructorFirstName;
          var InsLname= instructors[keys].InstructorLastName;
       const usersRef = firebaseAdmin.database().ref('Advice');
          return usersRef.once("value").then((snapshot) => {  
            let advisors = snapshot.val();
       var keys = Object.keys(advisors);
       var childVal = parseInt(keys[keys.length -1],10) + 1;
          if (childVal<10){childVal=`0${childVal}`;}
        usersRef.update({
        [childVal] : {
           AdviceEndDateTime: dateTimeEnd,
           AdviceStartDateTime: dateTimeStart,
           AdviceText: Atext ,
           AdviceTopic: Atopic,
           InstructorID: AdID,
           StudentID: stuID
    }
           });
       agent.add(`Your appointment with your advisor ${InsFname} ${InsLname} is booked. See you on ${appointmentTimeString} 😊`);
          });
          }); 
   });
  }

  
   function addInfo(agent) {
    const usersRef = firebaseAdmin.database().ref('Student');
    usersRef.update({
      '006': {
        DateOfBirth: '01/16/2003',
        FirstName: 'Moiz',
        LastName: 'Hashmi',
        Gender : 'Male',
        Citizenship : 'USA',
        AdvisorID: 1121
 }
        });
     agent.add("information was added");
  }
  
  
function PrerequistesOfCourse(agent) {
    var PId = agent.parameters.pid.toString();
    var PName = agent.parameters.pname.toString().toLowerCase();
    var ContextInfo = {
        "name": 'PCFB',
        "lifespan": 1,
        "parameters": {
            "param": "param value"
        }
    };

    function getPreq(PId) {
        return firebaseAdmin.database().ref('CourseRelationship').orderByChild('CourseID').equalTo(PId).once("value").then((snapshot) => {
            if (snapshot.exists()) {
                let sections = snapshot.val();
                var keys = Object.keys(sections);
                var prereq_ids = [];
                for (var k in keys) {
                    var prereq_id = sections[keys[k]].PrerequesiteID;
                    prereq_ids.push(prereq_id);
                }
                var f_prereq_id = prereq_ids[0];
                var l_prereq_id = prereq_ids[prereq_ids.length - 1];
                return firebaseAdmin.database().ref('Course').orderByChild('CourseID').startAt(f_prereq_id.toString()).endAt(l_prereq_id).once("value").then((snapshot) => {
                    let courses = snapshot.val();
                    var keys = Object.keys(courses);
                    var text = "";
                    var counter = 0;
                    for (var k in keys) {
                        text += courses[keys[k]].CourseID + ' ' + courses[keys[k]].Name + ",  ";
                        counter++;
                    }
                    var pre;
                    var ver;
                    if (counter > 1) {

                        pre = 'prerequisites';
                        ver = 'are';
                    } else {
                        pre = 'prerequisite';
                        ver = 'is';
                    }
                    var possibleResponse = [`The ${pre} for ${PId} ${ver} ${text}`, `${PId}'s ${pre} ${ver} ${text}`];
                    var pick = Math.floor(Math.random() * possibleResponse.length);
                    var response = possibleResponse[pick];
                    agent.add(response);
                });

            } else {
                agent.add('I am not able to find this course in the database. Please provide a valid course ID or name...');
                agent.setContext(ContextInfo);
            }
        });
    }

    function getID(PName) {
        return firebaseAdmin.database().ref('Course').orderByChild('Name').equalTo(PName).once("value").then((snapshot) => {
            if (snapshot.exists()) {
                let sections = snapshot.val();
                var keys = Object.keys(sections);
                PId = sections[keys].CourseID.toString();
                return getPreq(PId);
            }
        });
    }

    if (PId || PName) {
        if (PName && !PId) {
            return getID(PName);
        } else {
            return getPreq(PId);
        }

    } else {
        agent.add('Please provide a valid course ID or course name');
        agent.setContext(ContextInfo);
    }
}

 function CourseTeacherInfo(agent) {

    var Cname = agent.parameters.COName.toString();
    var CId = agent.parameters.COID.toString();
	var CurrentSemester = '202022';

    var ContextInfo = {
        "name": 'CTFB',
        "lifespan": 1,
        "parameters": { "param": "param value" }
    };

    function getCourseName(CId) {

        return firebaseAdmin.database().ref(`Section/${CurrentSemester}/${CId}`).once("value").then((snapshot) => {
            if (snapshot.exists()) {
               let ctix = {'name': 'ctix', 'lifespan': 5, 'parameters': {'param1':CId}};
               agent.setContext(ctix); 
                let sections = snapshot.val();
                var keys = Object.keys(sections);
                var instructor_ids = [];
                for (var k in keys) {
                    var instructor_id = sections[keys[k]].InstructorID;
                    instructor_ids.push(instructor_id);
                }
               
                return firebaseAdmin.database().ref('Instructor').once("value").then((snapshot) => {
                    let instructors = snapshot.val();
                    var keys = Object.keys(instructors);
                    var InsName = [];
                    var counter =0;
                    var keys_length = keys.length;
                    for (var k in keys) {
					     if (instructor_ids.includes(keys[k])) {
                        InsName.push( instructors[keys[k]].FirstName + " " + instructors[keys[k]].LastName);
                        counter++;}
                        
                    }
                  const payload = {"richContent":  [
    [
      {
        "type": "chips",
        "options": [
          {
            "text": `Yes, tell me about the timings of ${CId}`
	},
	    {
            "text": `No, thanks.`
	}
        ]
      }
    ]
  ] 
};

                    if (counter > 1) {
                        agent.add(`This semester the course ${CId} is taught by ${InsName[0]}, and ${InsName[1]}.\n Would you like to know  the timings of these sections?`);
                    agent.add(new Payload(agent.UNSPECIFIED, payload, {rawPayload: true, sendAsMessage: true}));
                    }
                    else { agent.add(`This semester the course ${CId} is taught by ${InsName}.\n Would you like to know  the timings of these sections?`);
                      agent.add(new Payload(agent.UNSPECIFIED, payload, {rawPayload: true, sendAsMessage: true}));}
                });
            }

            else {
              return firebaseAdmin.database().ref(`Course/${CId}`).once("value").then((snapshot) => { 
 if (snapshot.exists()) { 
   agent.add(`The course ${CId} is not offered this semester. Please provide a different course ID or name...:)`);
                agent.setContext(ContextInfo);
 }
 else{ agent.add('I am not able to find this course in the database. Please provide a valid course ID or name...:)');
                agent.setContext(ContextInfo);}
 });
                
            }
        });

    }

    function getCourseId(Cname) {
        return firebaseAdmin.database().ref('Course').orderByChild('Title').equalTo(Cname).once("value").then((snapshot) => {
            if (snapshot.exists()) {
                let sections = snapshot.val();
                var keys = Object.keys(sections);
                for (var k in keys) {
                    CId = keys[k].toString();
                    return getCourseName(CId);
                }
            }
          else {agent.add(`The course ${Cname} doesn't exisits. Please provide a valid course ID or course name... `);
                agent.setContext(ContextInfo);}
        });
    }

    if (CId || Cname) {
        if (Cname && !CId) {
            return getCourseId(Cname);
        } else {
            return getCourseName(CId);
        }

    } else {
        agent.add('Please provide a valid course ID or course name');
        agent.setContext(ContextInfo);
    }
}

  
  
  
 

function CanEnrollinCourse(agent) {
    var EnSID = agent.parameters.eSID.toString();
    var EnCourseID = agent.parameters.eID.toString();
    var EnName = agent.parameters.eName.toString().toLowerCase();
    var grade;
    var ContextInfo = {
        "name": 'CECFB',
        "lifespan": 1,
        "parameters": { "param": "param value" }
    };

    function getEnrollCourse(EnCourseID) {
        return firebaseAdmin.database().ref('Course').orderByChild('CourseID').equalTo(EnCourseID).once("value").then((snapshot) => {
            if (snapshot.exists()) {
                let CourseRelID = snapshot.val();
                var keys = Object.keys(CourseRelID);
                EnName = CourseRelID[keys].Name;
                return firebaseAdmin.database().ref('CourseRelationship').orderByChild('CourseID').equalTo(EnCourseID).once("value").then((snapshot) => {
                    let CourseRelID = snapshot.val();
                    var keys = Object.keys(CourseRelID);
                    var PreCID = CourseRelID[keys].PrerequesiteID;
                    var StatusID = CourseRelID[keys].Status;
                    if (StatusID != 'Open') {
                        agent.add(`The course ${EnCourseID} ${EnName} is currently not open for enrollment. Please contact your advisor for more options.`);
                    }
                    else if (StatusID == 'Open') {

                        return firebaseAdmin.database().ref('Enrollment').orderByChild('StudentID').equalTo(EnSID).once("value").then((snapshot) => {
                            if (snapshot.exists()) {
                                let Enval = snapshot.val();
                                var keys = Object.keys(Enval);
                                for (var k in keys) {
                                    let CeID = Enval[keys[k]].CourseID.toString();
                                    if (CeID == PreCID) {
                                        grade = Enval[keys[k]].Grade.toString();
                                    }
                                }
                                if (grade && grade != 'F' && grade != 'I') {
                                    agent.add(`The course CS-${EnCourseID} ${EnName} is open and you have completed the prerequiste CS-${PreCID} so you can enroll 😀`);
                                }
                                else if (grade == 'F') {
                                    agent.add(`Eventhough the course CS-${EnCourseID} ${EnName} is open but you have failed the prerequiste CS-${PreCID} so you cannot enroll`);
                                }
                                else if (grade == 'I') {
                                    agent.add(`Eventhough the course CS-${EnCourseID} ${EnName} is open but you have not completed the prerequiste CS-${PreCID} so you cannot enroll`);
                                }
                                else {
                                    agent.add(`Eventhough the course CS-${EnCourseID} ${EnName} is open but you have not taken the prerequiste CS-${PreCID} so you cannot enroll`);
                                }
                            }
                            else { agent.add(`The student Id ${EnSID} is invalid. Please provide the valid student it first and then reask the question`); }
                        });
                    }
                });
            }
            else {
                agent.add('I am not able to find this course in the database. Please provide a valid course ID or name...:)');
                agent.setContext(ContextInfo);
            }
        });
    }
    function getEnrollID(EnName) {
        return firebaseAdmin.database().ref('Course').orderByChild('Name').equalTo(EnName).once("value").then((snapshot) => {
            if (snapshot.exists()) {
                let CourseRelID = snapshot.val();
                var keys = Object.keys(CourseRelID);
                EnCourseID = CourseRelID[keys].CourseID;
                return getEnrollCourse(EnCourseID);
            }
        });
    }

    if (EnCourseID || EnName) {
        if (EnCourseID && !EnName) {
            return getEnrollCourse(EnCourseID);
        } else {
            return getEnrollID(EnName);
        }
    }
    else {
        agent.add('Please provide a valid course ID or course name');
        agent.setContext(ContextInfo);
    }
}

    
function HoursICanEnrollinSemester (agent) {
    var hID =agent.parameters.hId.toString();
    var ContextInfo = {
        "name": 'HCESFB',
      "lifespan": 1,
      "parameters":{"param": "param value"}
    }; 
    if (!hID){
             agent.add('Please provide your student ID first.');
             agent.setContext(ContextInfo);
                                       
    }
    else if (hID){  
    return firebaseAdmin.database().ref(`Student/${hID}`).once("value").then((snapshot) => {
    if (snapshot.exists()){     
    var CumGPA = snapshot.child('CGPA').val();
    var fname = snapshot.child('FirstName').val();
    var lname = snapshot.child('LastName').val();
    if (CumGPA < 2.5){  
    agent.add(`${fname} ${lname}, your cumulative GPA is ${CumGPA} which allows you to enroll in upto 16 credit hours this semester. `);
    }
    else if (CumGPA > 2.5 && CumGPA <= 3.5){  
    agent.add(`${fname} ${lname}, your cumulative GPA is ${CumGPA} which allows you to enroll in upto 19 credit hours this semester. `);
    }
    else if (CumGPA > 3.5){  
    agent.add(`${fname} ${lname}, your cumulative GPA is ${CumGPA} which allows you to enroll in upto 21 credit hours this semester, `);
    }
}
else{
    agent.add(`I am not able to find student Id ${hID} . Please provide a valid student ID...`);
   agent.setContext(ContextInfo);
  }
    });
    }
      
    }  
     

  
  
 function DontWantToTakeCourseThisSemester(agent) {
    var dcsID = agent.parameters.dcID.toString();
    var dcName = agent.parameters.dcname.toString().toLowerCase();
    var ContextInfo = {
        "name": 'DWTCFB',
        "lifespan": 1,
        "parameters": { "param": "param value" }
    };
    function getDontWantTakeCourseThisSemesterName(dcsID) {
        return firebaseAdmin.database().ref('Course').orderByChild('CourseID').equalTo(dcsID).once("value").then((snapshot) => {
            if (snapshot.exists()) {
                let CourseRelDID = snapshot.val();
                var keys = Object.keys(CourseRelDID);
                dcName = CourseRelDID[keys].Name;
                return firebaseAdmin.database().ref('CourseRelationship').orderByChild('CourseID').equalTo(dcsID).once("value").then((snapshot) => {
                    let CourseRelDID = snapshot.val();
                    var keys = Object.keys(CourseRelDID);
                    var PrereqID = CourseRelDID[keys].PrerequesiteID;
                    return firebaseAdmin.database().ref('Course').orderByChild('CourseID').equalTo(PrereqID).once("value").then((snapshot) => {
                        let CourseRelDID = snapshot.val();
                        var keys = Object.keys(CourseRelDID);
                        var dcName1 = CourseRelDID[keys].Name;
                        agent.add(`I know you may have valid reason to skip Cs-${dcsID}-${dcName} this semester but this course is prerequisite to CS-${PrereqID}-${dcName1} and not taking ${dcName} may delay your gradutation ☹️. Please consult your advisor for more details.`);
                    });
                });
            }
            else {
                agent.add('I am not able to find this course in the database. Please provide a valid course title or ID again.');
                agent.setContext(ContextInfo);
            }

        });
    }
    function getDontWantTakeCourseThisSemesterID(dcName) {
        return firebaseAdmin.database().ref('Course').orderByChild('Name').equalTo(dcName).once("value").then((snapshot) => {
            if (snapshot.exists()) {
                let CourseRelDID = snapshot.val();
                var keys = Object.keys(CourseRelDID);
                dcsID = CourseRelDID[keys].CourseID.toString();
                return getDontWantTakeCourseThisSemesterName(dcsID);
            }
        });
    }

    if (dcsID || dcName) {
        if (dcsID && !dcName) {
            return getDontWantTakeCourseThisSemesterName(dcsID);
        }
        else {
            return getDontWantTakeCourseThisSemesterID(dcName);
        }

    }

    else {
        agent.add('Please provide a valid course ID or course name');
        agent.setContext(ContextInfo);
    }
}

  
function RetakeACourse(agent) {
    var RcID = agent.parameters.RcIDi.toString();
    var RsID = agent.parameters.RsIDi.toString();
    var RcName = agent.parameters.RcNamei.toString().toLowerCase();
    var gradeR;
    var ContextInfo = {
        "name": 'RTCFB',
        "lifespan": 1,
        "parameters": { "param": "param value" }
    };

    function getRetakeACourseName(RcID) {
        return firebaseAdmin.database().ref('Course').orderByChild('CourseID').equalTo(RcID).once("value").then((snapshot) => {
            if (snapshot.exists()) {
                let CourseRelID = snapshot.val();
                var keys = Object.keys(CourseRelID);
                RcName = CourseRelID[keys].Name;
                return firebaseAdmin.database().ref('Enrollment').orderByChild('CourseID').equalTo(RcID).once("value").then((snapshot) => {
                    let CourseRelRID = snapshot.val();
                    var keys = Object.keys(CourseRelRID);
                    for (var k in keys) {
                        var suRID = CourseRelRID[keys[k]].StudentID.toString();
                        if (suRID == RsID) {
                            gradeR = CourseRelRID[keys[k]].Grade.toString();
                        }
                    }
                    if (gradeR && gradeR != 'F' && gradeR != 'I') {
                        agent.add(`You have already passed CS-${RcID}  ${RcName} with grade ${gradeR} so you cannot retake it.`);
                    }
                    else if (gradeR == 'F') {
                        agent.add(`Since you have failed CS-${RcID} ${RcName} (grade = ${gradeR}) so you can retake it.`);
                    }
                    else if (!gradeR) {
                        agent.add(`Our record shows that you have not taken CS-${RcID} ${RcName} before (or not graded for this course),  so you can enroll in the course if you have completed the prerequisite of this course.`);
                    }
                });
            }
            else {
                agent.add('We could not find this course in the database. Please provide us with the course title or ID again.');
                agent.setContext(ContextInfo);
            }
        });
    }
    function getRetakeACourseID(RcName) {
        return firebaseAdmin.database().ref('Course').orderByChild('Name').equalTo(RcName).once("value").then((snapshot) => {
            if (snapshot.exists()) {
                let CourseRelID = snapshot.val();
                var keys = Object.keys(CourseRelID);
                RcID = CourseRelID[keys].CourseID;
                return getRetakeACourseName(RcID);
            }
        });
    }
    if (RcID || RcName) {
        if (RcID && !RcName) {
            return getRetakeACourseName(RcID);
        }
        else {
            return getRetakeACourseName(RcName);
        }
    }

    else {
        agent.add('Please provide a valid course ID or course name');
        agent.setContext(ContextInfo);
    }
}



  
  function DontWantToTakeCourseWithInstructor(agent) {

    var Cname = agent.parameters.CONameI.toString().toLowerCase();
    var CId = agent.parameters.COIDI.toString();
    var InName = agent.parameters.InsName.toString().toLowerCase();
    var ContextInfo = {
        "name": 'DWTTCWIFB',
        "lifespan": 1,
        "parameters": { "param": "param value" }
    };

    function getDontWantTakeCourseWithInstructorName(CId) {

        return firebaseAdmin.database().ref('Section').orderByChild('CourseID').equalTo(CId).once("value").then((snapshot) => {
            if (snapshot.exists()) {
                let sections = snapshot.val();
                var keys = Object.keys(sections);
                var instructor_ids = [];
                for (var k in keys) {
                    var instructor_id = sections[keys[k]].InstructorID;
                    instructor_ids.push(instructor_id);
                }
                var f_instructor_id = instructor_ids[0];
                var l_instructor_id = instructor_ids[instructor_ids.length - 1];
                return firebaseAdmin.database().ref('Instructor').orderByChild('InstructorID').startAt(f_instructor_id.toString()).endAt(l_instructor_id).once("value").then((snapshot) => {
                    let instructors = snapshot.val();
                    var keys = Object.keys(instructors);
                    var text = "";

                    for (var k in keys) {
                        text += instructors[keys[k]].InstructorFirstName + " " + instructors[keys[k]].InstructorLastName + ",  ";

                    }
                    var textA = text.toLowerCase().replace(`${InName},`, "");
                    if (textA.length > 5) {
                        agent.add(`You can take ${Cname} with:  ${textA}`);
                    }
                    else if (textA.length < 5) {
                        agent.add(`Unfortunately, you must take ${Cname} with instructor ${text}, and you can book appointments with TAs for more help.`);
                    }
                });
            }

            else {
                agent.add('I am not able to find this course in the database. Please provide a valid course ID or name...:)');
                agent.setContext(ContextInfo);
            }
        });
    }

    function getDontWantTakeCourseWithInstructorID(Cname) {
        return firebaseAdmin.database().ref('Course').orderByChild('Name').equalTo(Cname).once("value").then((snapshot) => {
            if (snapshot.exists()) {
                let sections = snapshot.val();
                var keys = Object.keys(sections);
                for (var k in keys) {
                    CId = sections[keys[k]].CourseID.toString();

                    return getDontWantTakeCourseWithInstructorName(CId);
                }
            }
        });
    }
    if (CId || Cname) {
        if (CId && !Cname) {
            return getDontWantTakeCourseWithInstructorName(CId);
        }
        else {
            return getDontWantTakeCourseWithInstructorID(Cname);
        }
    }

    else {
        agent.add('Please provide a valid course ID or course name');
        agent.setContext(ContextInfo);
    }

}

  


  

function test(agent) {
var Cname = "intro to statistical learning";
    var CId;
   
    var ContextInfo = {
    "name": 'CTFB',
  "lifespan": 1,
  "parameters":{"param": "param value"}
}; 
  if (CId || Cname){
    if (Cname && !CId){
    return firebaseAdmin.database().ref('Course').orderByChild('Name').equalTo(Cname).once("value").then((snapshot)=>{
      if (snapshot.exists()){
        let sections = snapshot.val();
        var keys = Object.keys(sections);
           for(var k in keys){
           CId = sections[keys[k]].CourseID.toString();
           
		  }
       
    }
	else {agent.add('invalid course name');} 
	});
	}
   
   return firebaseAdmin.database().ref('Section').orderByChild('CourseID').equalTo(CId).once("value").then((snapshot)=>{
      agent.add(`here is the value of CID in section part ${CId}`);     
     if (snapshot.exists()){
           let sections = snapshot.val();
     var keys = Object.keys(sections);
     var instructor_ids=[];
     for(var k in keys){
       var instructor_id=sections[keys[k]].InstructorID;
       instructor_ids.push(instructor_id);
     }
        var f_instructor_id=instructor_ids[0];
     var l_instructor_id=instructor_ids[instructor_ids.length-1];  
       return firebaseAdmin.database().ref('Instructor').orderByChild('InstructorID').startAt(f_instructor_id.toString()).endAt(l_instructor_id).once("value").then((snapshot) => {     
       let instructors = snapshot.val();
       var keys = Object.keys(instructors);
       var keys_length=keys.length;
       var text="";
       var counter=0;
       for(var k in keys){
         text+=instructors[keys[k]].InstructorFirstName+" "+instructors[keys[k]].InstructorLastName;
        counter++;
         if(counter<keys_length)
           text+=", ";        
     }
         if (counter > 1){
           agent.add(`The instructors for CS-${CId} are ${text}`);}
         else { agent.add(`The instructor for CS-${CId} is ${text}`);}
       }); 
       }
     
           else {
  agent.add('I am not able to find this instructor in the database. Please provide a valid course ID or name...:)');
  agent.setContext(ContextInfo);
  }
    });
   }                                                                                                     
  
  else {
  agent.add('Please provide a valid course ID or course name');
  agent.setContext(ContextInfo);
  }
  }  

  
 function test1(agent){
 agent.add(new Table({
  dividers: true,
  columns: ['header 1', 'header 2', 'header 3'],
  rows: [
    ['row 1 item 1', 'row 1 item 2', 'row 1 item 3'],
    ['row 2 item 1', 'row 2 item 2', 'row 2 item 3'],
  ],
}));
  
 } 
  
  
function ZUElective(agent){
  const payload = {"richContent":  [
    [
      {
        "type": "image",
        "rawUrl": "http://organicbudget.us/images/zu_logo.jpg",
        "accessibilityText": "Zayed University",
        "height":"40px"
      },
      {
        "type": "info",
        "title": "Zayed University ",
        "subtitle": "Please click below to visit ZU elective catalog page",
        "actionLink": "https://cloud.google.com/dialogflow/docs"
      },
      {
        "type": "button",
        "icon": {
          "type": "*",
          "color": "#FF9800"
        },
        "text": "ZU elective Page",
        "link": "https://www.zu.ac.ae/main/en/explore_zu/catalog/index.aspx",
        "event": {
          "name": "",
          "languageCode": "",
          "parameters": {}
        }
      },
      {
        "type": "chips",
        "options": [
          {
            "text": "About ZU",
            "link": "https://www.zu.ac.ae/main/en/explore_zu/index.aspx"
          },
          {
            "text": "ZU Home",
            "link": "https://www.zu.ac.ae/main/en/index.aspx"
          }
        ]
      }
    ]
  ]
  
};

agent.add(
  new Payload(agent.UNSPECIFIED, payload, {rawPayload: true, sendAsMessage: true})
);
  
}
  
 function InformationAboutStudentClubs (agent){ 
 const payload = {"richContent":  [
    [
      {
        "type": "image",
        "rawUrl": "https://www.zu.ac.ae/main/en/student-leadership-office/_images/headers/header-clubs-main.jpg",
        "accessibilityText": "ZU student club"
      },
      {
        "type": "info",
        "title": "ZU Clubs",
        "subtitle": "Please click the link below to visit ZU student club info page",
        "actionLink": "https://www.zu.ac.ae/main/en/student-leadership-office/student-clubs/list.aspx"
      },
      {
        "type": "button",
        "icon": {
          "type": "*",
          "color": "#FF9800"
        },
        "text": "ZU Student Club Page",
        "link": "https://www.zu.ac.ae/main/en/student-leadership-office/student-clubs/list.aspx",
        "event": {
          "name": "",
          "languageCode": "",
          "parameters": {}
        }
      }
    ]
  ]
  
};

agent.add(
  new Payload(agent.UNSPECIFIED, payload, {rawPayload: true, sendAsMessage: true})
);  
   
 } 

  function ContactForInternship (agent){ 
     const payload = {"richContent":  [
    [
      {
        "type": "image",
        "rawUrl": "https://www.zu.ac.ae/main/en/colleges/colleges/__college_of_technological_innovation/faculty_and_staff/_profiles/CIT_Fac-Staff-pics/Maurice.dan.jpg",
        "accessibilityText": "Dr. Maurice Danaher"
      },
      {
        "type": "info",
        "title": "Dr. Maurice Danaher",
        "subtitle": "Please contact Dr. Maurice Danaher for all internship related questions.  You can click on the link below to visit his webpage or reach him at maurice.danaher@zu.ac.ae",
        "actionLink": "https://www.zu.ac.ae/main/en/colleges/colleges/__college_of_technological_innovation/faculty_and_staff/_profiles/Maurice_Danaher.aspx"
      },
      {
        "type": "button",
        "icon": {
          "type": "*",
          "color": "#FF9800"
        },
        "text": "Dr. Maurice Danaher profile",
        "link": "https://www.zu.ac.ae/main/en/colleges/colleges/__college_of_technological_innovation/faculty_and_staff/_profiles/Maurice_Danaher.aspx",
        "event": {
          "name": "",
          "languageCode": "",
          "parameters": {}
        }
      }
    ]
  ]
  
};

agent.add(
  new Payload(agent.UNSPECIFIED, payload, {rawPayload: true, sendAsMessage: true})
);  
    
 } 
  
  function GradeDispute (agent){ 
       const payload = {"richContent":  [
    [
      {
        "type": "image",
        "rawUrl": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSC3BU5Wk_lW1XU9tFTlGfjkKPWgeGaUTmryw&usqp=CAU",
        "accessibilityText": "Grade Appeal"
      },
      {
        "type": "info",
        "title": "Grade Appeal Procedurer",
        "subtitle": "You can submit grade dispute. Appeals must be submitted within three working days of the posting of the final grades. please click the link below to access online request form.",
        "actionLink": "https://www.zu.ac.ae/main/en/colleges/colleges/__college_of_technological_innovation/faculty_and_staff/_profiles/Maurice_Danaher.aspx"
      },
      {
        "type": "button",
        "icon": {
          "type": "*",
          "color": "#FF9800"
        },
        "text": "Grade Appeal request form link",
        "link": "https://academicforms.zu.ac.ae/Account?u=0&ReturnUrl=/Forms",
        "event": {
          "name": "",
          "languageCode": "",
          "parameters": {}
        }
      }
    ]
  ]
  
};

agent.add(
  new Payload(agent.UNSPECIFIED, payload, {rawPayload: true, sendAsMessage: true})
);   
    
 } 
  
  function WhenCanIGraduate(agent) {

    var Id = agent.parameters.SID.toString();
    var ContextInfo = {
        "name": 'WCIG',
        "lifespan": 1,
        "parameters": { "param": "param value" }
    };
 const payload = {
        "richContent": [
            [
                {
                    "type": "image",
                    "rawUrl": "https://aau.ac.ae/uploads/2018/10/20181017182303.jpg",
                    "accessibilityText": "Graduation Info"
                },
                {
                    "type": "info",
                    "title": "Zayed University Graduation Requirement ",
                    "subtitle": "Each college in the Zayed University has its own graduation requirements. Please select your college below for more information.",
                    "actionLink": "https://www.zu.ac.ae/main/en/colleges/colleges/__college_of_education/existing_students/graduation_requirements.aspx"
                    //"actionLink": "https://cloud.google.com/dialogflow/docs"
                },

                {
                    "type": "chips",
                    "options": [
                        {
                            "text": "College of Business",
                            "link": "https://www.zu.ac.ae/main/en/colleges/colleges/__college_of_business/existing_students/graduation_requirements.aspx#:~:text=Proficiency%20in%20English%2C,internship%20as%20its%20only%20requirement."
                        },
                        {
                            "text": "College of Education",
                            "link": "https://www.zu.ac.ae/main/en/colleges/colleges/__college_of_education/existing_students/graduation_requirements.aspx"
                        },
                        {
                            "text": "College of Arts and Creative Enterprises",
                            "link": "https://www.zu.ac.ae/main/en/colleges/colleges/__college_of_arts_and_creative_enterprises/faculty_and_staff/index.aspx"
                        },
                        {
                            "text": "College of Communication and Media Sciences",
                            "link": "https://www.zu.ac.ae/main/en/colleges/colleges/__college_of_comm_media_sciences/index.aspx"
                        },
                        {
                            "text": "College of Humanities and Social Sciences",
                            "link": "https://www.zu.ac.ae/main/en/colleges/colleges/__college_of_humanities_and_social_sciences/index.aspx"
                        },
                        {
                            "text": "College of Natural and Health Sciences",
                            "link": "https://www.zu.ac.ae/main/en/colleges/colleges/__college_of_natural_and_health_sciences/existing_students.aspx"
                        },
                        {
                            "text": "College of Technological Innovation",
                            "link": "https://www.zu.ac.ae/main/en/colleges/colleges/__college_of_technological_innovation/existing_students/index.aspx"
                        }
                    ]
                }
            ]
        ]

    };
    agent.add(
        new Payload(agent.UNSPECIFIED, payload, { rawPayload: true, sendAsMessage: true })
    );
  
}
  
  const axios = require('axios');
  function rhymingWordHandler(agent){
    const word = agent.parameters.word;
    agent.add(`Here are the rhyming words for ${word}`);
    return axios.get(`https://api.datamuse.com/words?rel_rhy=${word}`)
    .then((result) => {
        result.data.map(wordObj => {
        	agent.add(wordObj.word);
        });
    });
  }
  
  const fetch= require('node-fetch');
  function HavingHardTimeStrugglingWithCourses (agent){
    var myHeaders = new fetch.Headers();
//myHeaders.append("apikey", "ZtyPTPVwBQ167YQgastPjf6sCiwORbXo");
myHeaders.append("apikey", "9oa16fMPaZJy7gfKnGE6QRSzlDl3pp6F");
var raw = agent.parameters.tex.toString();

var requestOptions = {
  method: 'POST',
  redirect: 'follow',
  headers: myHeaders,
  body: raw
};

return fetch("https://api.promptapi.com/text_to_emotion", requestOptions)
  .then(response => response.text())
  .then(result => {var apires =JSON.parse(result);
let maxKey = Object.keys(apires).reduce((a, b) => apires[a] > apires[b] ? a : b);
if (maxKey == 'Happy'){
    agent.add('I am glad to hear that. Your sucess means a lot to us.');
}
else if (maxKey == 'Angry'){
     agent.add('Sorry things aren\'t working for you.\n I  understand that stress and anxiety can be quite challenging for students.\n For more help, plase reach out to Student Counseling Center at - 025993590 (AUH) & 044021637 (DXB) or email counseling@zu.ac.ae. ');
}
else if (maxKey == 'Surprise'){
     agent.add('Hmm that is intresting. Can you tell me more about this scenario?');
}
else if (maxKey == 'Sad'){
     agent.add('I am sorry to hear that. Stick with me. We\'ll figure this out together');
}
else if (maxKey == 'Fear'){
     agent.add('There is no reason to be afraid. I am here to help.');
}
else { agent.add('Sorry things aren\'t working for you.\n I  understand that stress and anxiety can be quite challenging for students.\n For more help, plase reach out to Student Counseling Center at - 025993590 (AUH) & 044021637 (DXB) or email counseling@zu.ac.ae. ');

     
     }               })
 
  .catch(error => agent.add('error', error));
  }
  
function RequestMyInformation(agent) {
	const detailsArray = {"CGPA":"CGPA", "Citizenship":"citizenship", "DateOfBirth":"date of birth", "FirstName":"first name", "Gender":"gender", "LastName":"last name"};
    var Stud_ID = agent.parameters.Student_ID.toString();
    var details = agent.parameters.StudentDetails.toString();        
    return firebaseAdmin.database().ref(`Student/${Stud_ID}`).once('value').then((snapshot) => {
		if (details == 'AdvisorID') {
          		let Advisor_ID = snapshot.child(`${details}`).val();
        		return firebaseAdmin.database().ref(`Instructor/${Advisor_ID}`).once('value').then((snapshot) => {
            			let AdvisorFName = snapshot.child('InstructorFirstName').val();
              			let AdvisorLName = snapshot.child('InstructorLastName').val();	
            			agent.add(`Your advisor is ${AdvisorFName} ${AdvisorLName}.`);
            		});
        	} else {
			let details_fixed = detailsArray[`${details}`];
          		let Student_Detail = snapshot.child(`${details}`).val();
          		agent.add(`Your ${details_fixed} is ${Student_Detail}`);
        	}	
     	});
  }


  function checkTeacherName2(agent) {
  const  fuzz = require('fuzzball');
    var Insname = agent.parameters.CheckName.toString();
    return firebaseAdmin.database().ref('Instructor').once("value").then((snapshot) => {
    let instructors = snapshot.val();
       var keys = Object.keys(instructors);
       var keys_length=keys.length;
       var text=[];
       var counter=0;
       for(var k in keys){
         text.push(instructors[keys[k]].InstructorFirstName+" "+instructors[keys[k]].InstructorLastName);
        counter++;
         //if(counter<keys_length)
           //text+=", ";        
     }
 var threshold=50; 
 var teachername=[];
var arrayLength = text.length;
for (var i = 0; i < arrayLength; i++){
  var fuzz_ratio = fuzz.ratio(Insname, text[i]);
  if (fuzz_ratio>threshold){
    //threshold=fuzz_ratio;
    teachername.push(text[i]);
  }
   
}
      
      agent.add(`The name you provided is ${Insname} and name in database is  ${teachername} and matching score is ${threshold}`);
    });
  }
    
 
  function DiscussingLowPerformance(agent){
   var Id = agent.parameters.SID.toString();
   var lastSemester='202021';
    var CurrentSemester='202022';
    let coursename = [];
  
  
    var ContextInfo = {
    "name": 'DLPFB',
  "lifespan": 1,
  "parameters":{"param": "param value"}
};  
   
   return firebaseAdmin.database().ref(`Student/${Id}`).once("value").then((snapshot) => {
      if (snapshot.exists()) {
         let FName= snapshot.child('FirstName').val();
         let LName= snapshot.child('LastName').val();
		 let GPA= snapshot.child('CGPA').val();
	if (GPA == 4){
	agent.add(`You have an excellent GPA! You just need to keep it up.\n Nevertheless, you may benefit from resources available to help you with coursework.
You may benefit from resources helping you to cope with stress and other issues affecting your performance.`);
    const payload = {"richContent":  [
    [
      {
        "type": "chips",
        "options": [
           {
            "text": " I need resources to help me with coursework."
          },
          {
            "text": " I need resources to help me with stress and issues affecting my performance."
          },
          {
            "text": " I have an issue with a certain instructor, and it is affecting my performance."
          },
          {
            "text": "  I think one of the grades I received is unfair."
          }
        ]
      }
    ]
  ] 
};

agent.add(
  new Payload(agent.UNSPECIFIED, payload, {rawPayload: true, sendAsMessage: true})

);}
	else if(GPA != 4) {
   return firebaseAdmin.database().ref(`Enrollment/${Id}/${lastSemester}`).once("value").then((snapshot) => {     
     let enrollsnap=snapshot.val();
     var grade;
    
                    var keys = Object.keys(enrollsnap);
                    for (var k in keys) {
                       grade=enrollsnap[keys[k]].Grade.toString();
                        if (grade == 'F' ){
                          
                         coursename.push(keys[k]);
                            
                        }
                    }
    let ctx = {'name': 'ctx', 'lifespan': 5, 'parameters': {'param1':coursename}};
    agent.setContext(ctx);  
  if (coursename.length != 0){
   return firebaseAdmin.database().ref(`Section/${CurrentSemester}/${coursename[0]}`).once("value").then((snapshot) =>{
  if (snapshot.exists()) {
     let Secsnap=snapshot.val();
      var status;
    
   var found=1;
    var keys = Object.keys(Secsnap);
   for (var k in keys) {
      status=Secsnap[keys[k]].Status.toString();
     
     if (status == 'Open'){found= ++found;}
   }
   if (found >1){
   agent.add( ` There are several ways for improving your GPA:\n You can retake course ${coursename} that you failed in semester ${lastSemester}.\n
  You may benefit from resources available to help you with coursework.\n You may benefit from resources helping you to cope with stress and other issues affecting your performance.`);
   
      const payload = {"richContent":  [
    [
      {
        "type": "chips",
        "options": [
          {
            "text": `I want to retake course ${coursename[0]} with a certain professor`
          },
		  {
            "text": `I don't want to retake course ${coursename[0]} with a certain professor`
          },
		  {
            "text": `I want to retake course ${coursename[0]}, but it's too tough`
          },
          {
            "text": " I need resources to help me with coursework."
          },
          {
            "text": " I need resources to help me with stress and issues affecting my performance."
          },
          {
            "text": " I have an issue with a certain instructor, and it is affecting my performance."
          },
          {
            "text": "  I think one of the grades I received is unfair."
          }
        ]
      }
    ]
  ] 
};

agent.add(
  new Payload(agent.UNSPECIFIED, payload, {rawPayload: true, sendAsMessage: true})

);
 } 
else if (found == 1){
agent.add(`There are several ways for improving your GPA:\n You can retake course ${coursename} that you failed in semester ${lastSemester}.\n
  You may benefit from resources available to help you with coursework.\n You may benefit from resources helping you to cope with stress and other issues affecting your performance.`);
   const payload = {"richContent":  [
    [
      {
        "type": "chips",
        "options": [
           {
            "text": " I need resources to help me with coursework."
          },
          {
            "text": " I need resources to help me with stress and issues affecting my performance."
          },
          {
            "text": " I have an issue with a certain instructor, and it is affecting my performance."
          },
          {
            "text": "  I think one of the grades I received is unfair."
          }
        ]
      }
    ]
  ] 
};

agent.add(
  new Payload(agent.UNSPECIFIED, payload, {rawPayload: true, sendAsMessage: true})

);





} 
  }
  else{agent.add(`There are several ways for improving your GPA:\n You can retake course ${coursename} that you failed in semester ${lastSemester}.\n
  You may benefit from resources available to help you with coursework.\n You may benefit from resources helping you to cope with stress and other issues affecting your performance.`);
  const payload = {"richContent":  [
    [
      {
        "type": "chips",
        "options": [
          {
            "text": "I need resources to help me with coursework."
          },
		  {
            "text": " I need resources to help me with stress and issues affecting my performance."
          },
          {
            "text": " I have an issue with a certain instructor, and it is affecting my performance."
          },
          {
            "text": "I think one of the grades I received is unfair."
          }
        ]
      }
    ]
  ] 
};

agent.add(
  new Payload(agent.UNSPECIFIED, payload, {rawPayload: true, sendAsMessage: true})

);
  }
  });
  }
  else{agent.add(`There are several ways for improving your GPA.\n You may benefit from resources available to help you with coursework.
You may benefit from resources helping you to cope with stress and other issues affecting your performance.`);
   const payload = {"richContent":  [
    [
      {
        "type": "chips",
        "options": [
           {
            "text": " I need resources to help me with coursework."
          },
          {
            "text": " I need resources to help me with stress and issues affecting my performance."
          },
          {
            "text": " I have an issue with a certain instructor, and it is affecting my performance."
          },
          {
            "text": "  I think one of the grades I received is unfair."
          }
        ]
      }
    ]
  ] 
};

agent.add(
  new Payload(agent.UNSPECIFIED, payload, {rawPayload: true, sendAsMessage: true})

);   
      }  
   });
      
    }
        
      }
    else {
                agent.add('I am not able to find this Student ID in the database, please provide a valid student ID.');
                agent.setContext(ContextInfo);
                
            }
 
 }); 
   }

    
   function DiscussingLowPerformance2_2_instructorName(agent){
    var ContextInfo = {
    "name": 'DLP2INFB',
  "lifespan": 1,
  "parameters":{"param": "param value"}
};
  var CurrentSemester='202022';
  var Insname= agent.parameters.checkname.toString();
  var firstName = Insname.split(' ').slice(0, -1).join(' ');
  var lastName = Insname.split(' ').slice(-1).join(' ');  
  let params = agent.getContext('ctx').parameters;
  let param1 = params.param1;
 return firebaseAdmin.database().ref('Instructor').orderByChild('FirstName').equalTo(firstName).once("value").then((snapshot) => {
  if (snapshot.exists()) {
    let Inssnap=snapshot.val();
     var InsId;
    var checname;
    var keys = Object.keys(Inssnap);
    for (var k in keys) {
       checname= (Inssnap[keys[k]].FirstName.toString()+" "+Inssnap[keys[k]].LastName.toString());
       if (checname == Insname){
         InsId=keys[k].toString();
       } 
     }
 return firebaseAdmin.database().ref(`Section/${CurrentSemester}/${param1}`).once("value").then((snapshot) =>{
  if (snapshot.exists()) {
    let Secsnap=snapshot.val();
      var status;
    var InsID1;
   var found=1;
   var InsCount=1;
    var keys = Object.keys(Secsnap);
   for (var k in keys) {
      status=Secsnap[keys[k]].Status.toString();
     InsID1=Secsnap[keys[k]].InstructorID.toString();
     if (InsID1 == InsId ){
	 InsCount= ++InsCount;
	 if (status == 'Open'){
	 
	 found= ++found;}
	 }
   }
   
   if (InsCount>1 && found >1){
   agent.add(`Sure, you can take the course ${param1} with instructor ${Insname}.`);
    const payload = {"richContent":  [
    [
      {
        "type": "chips",
        "options": [
          {
            "text": "How can I register in a class",
			"link": "https://eservices.zu.ac.ae/main/Services/Servicecard/Undergraduate/Student-Course-Registration-"
          }
        ]
      }
    ]
  ] 
};

agent.add(
  new Payload(agent.UNSPECIFIED, payload, {rawPayload: true, sendAsMessage: true})
);
  
   }
   else if(InsCount>1 && found == 1){agent.add(`Unfortunately, the course ${param1} is taught by instructor ${Insname} this semester. However, this instructor's section is closed for registeration.`);}
   else if (InsCount == 1 && found == 1){agent.add(`Unfortunately, the course ${param1} is not taught by instructor ${Insname} this semester.`);}
  }   
  else{agent.add(`The Course ${param1} is not offered in the semester ${CurrentSemester}.`);} 
 });
     }
   else{agent.add(`I am not able to find ${Insname} in the database, please provide a valid Instructor name.`);
        agent.setContext(ContextInfo);}
 });
    
      }
  
   function DiscussingLowPerformance2_3_instructorName(agent){
    var ContextInfo = {
    "name": 'DLP3INFB',
  "lifespan": 1,
  "parameters":{"param": "param value"}
};
  var CurrentSemester='202022';
  var Insname= agent.parameters.checkname.toString();
  var firstName = Insname.split(' ').slice(0, -1).join(' ');
  var lastName = Insname.split(' ').slice(-1).join(' ');  
  let params = agent.getContext('ctx').parameters;
  let param1 = params.param1;
 return firebaseAdmin.database().ref('Instructor').orderByChild('FirstName').equalTo(firstName).once("value").then((snapshot) => {
  if (snapshot.exists()) {
    let Inssnap=snapshot.val();
     var InsId;
    var checname;
    var keys = Object.keys(Inssnap);
    for (var k in keys) {
       checname= (Inssnap[keys[k]].FirstName.toString()+" "+Inssnap[keys[k]].LastName.toString());
       if (checname == Insname){
         InsId=keys[k].toString();
       } 
     }
 return firebaseAdmin.database().ref(`Section/${CurrentSemester}/${param1}`).once("value").then((snapshot) =>{
  if (snapshot.exists()) {
    let Secsnap=snapshot.val();
      var InsID1;
    var status;
    var OnlyIns=1;
   var Instructor=[];
    var keys = Object.keys(Secsnap);
   for (var k in keys) {
      InsID1=Secsnap[keys[k]].InstructorID.toString();
      status =Secsnap[keys[k]].Status.toString();
     if (InsID1 != InsId && status == 'Open'){Instructor.push(InsID1);}
     else if (InsID1 == InsId && status == 'Open'){OnlyIns = ++OnlyIns;}
   }
   
   if (Instructor.length > 0){
     var Insname1=[];
      return firebaseAdmin.database().ref(`Instructor`).once("value").then((snapshot) => {
    let Insnap=snapshot.val();
      var InsID1;
    var keys = Object.keys(Insnap);
   for (var k in keys) {
    if (Instructor.includes(keys[k])){
     Insname1.push(Insnap[keys[k]].FirstName.toString()+" "+Insnap[keys[k]].LastName.toString());
     }
   }
   if(Insname1.length > 0){
   agent.add(`Sure, you can take the course with these instructors  ${Insname1}.`);
    const payload = {"richContent":  [
    [
      {
        "type": "chips",
        "options": [
          {
            "text": "How can I register in a class",
			"link": "https://eservices.zu.ac.ae/main/Services/Servicecard/Undergraduate/Student-Course-Registration-"
          }
        ]
      }
    ]
  ] 
};

agent.add(
  new Payload(agent.UNSPECIFIED, payload, {rawPayload: true, sendAsMessage: true})
);       
   }  });
     
 
  
   }
   else if (Instructor.length < 1 && OnlyIns > 1){agent.add(`Unfortunately, the course is only taught by instructor ${Insname} this semester.`);}
  } 
else{agent.add(`The Course ${param1} is not offered in the semester ${CurrentSemester}.`);}  
 });
     }
   else{agent.add(`I am not able to find ${Insname} in the database, please provide a valid Instructor name.`);
        agent.setContext(ContextInfo);}
 });
    
      }
  

function  StudentNotUnderstandingCourseMaterials(agent){
  
   let CoCode = agent.parameters.CoCode.toString();
   let CoName = agent.parameters.CoName.toString();
     var ContextInfo = {
        "name": 'SNUCMFB',
        "lifespan": 1,
        "parameters": { "param": "param value" }
    };
  
   function StudentNotUnderstandingCourseContent(content){
  return firebaseAdmin.database().ref(`Course/${content}`).once("value").then((snapshot) => {
  if (snapshot.exists()) {
  var ctype= snapshot.child('College').val().toString();
    
    if(ctype != 'CTI'){
    agent.add(`Here are some ways to help you with the course: `);
    const payload = {"richContent":  [
    [
      {
        "type": "button",
        "icon": {
          "type": "chevron_right",
          "color": "#FF9800"
        },
        "text": "Contact the Math Cafe. They will be glad to help you.",
        "link": "https://www.zu.ac.ae/main/en/colleges/colleges/__college_of_natural_and_health_sciences/Student_Affairs/_Pages/Math_Cafe.aspx",
        "event": {
          "name": "",
          "languageCode": "",
          "parameters": {}
        }
      },
       {
        "type": "divider"
      },
      {
        "type": "button",
        "icon": {
          "type": "chevron_right",
          "color": "#FF9800"
        },
        "text": "Contact the Peer Assistance Leaders (PALs) to help you with your studies in collaboration with students like yourself.",
        "link": "https://www.zu.ac.ae/main/en/ocd/Pals/index.aspx",
        "event": {
          "name": "",
          "languageCode": "",
          "parameters": {}
        }
      }
    ]
  ]
     
};

agent.add(
  new Payload(agent.UNSPECIFIED, payload, {rawPayload: true, sendAsMessage: true})
);
  
   

    }
 else if (ctype == 'CTI'){
   var currentSemester='202022';
    return firebaseAdmin.database().ref(`Section/${currentSemester}/${content}`).once("value").then((snapshot) => {
    let Secsnap=snapshot.val();
   var TAinfo=[];
    var keys = Object.keys(Secsnap);
      var Section;
      var TaName;
      var TaEmail;
   for (var k in keys) {
     Section = keys[k];
     TaName = Secsnap[keys[k]].TAName.toString();
     TaEmail =  Secsnap[keys[k]].TAEmail.toString();
     if ((TaName !==' ' && TaName !== null) && (TaEmail !==' ' && TaEmail !== null)){
     TAinfo.push("Section: "+Section+", TA Name:  "+TaName+", TA Email: "+TaEmail+" ");}
    }
    agent.add(`Here are some ways to help you with the course: \n We have TAs (Teahcer Assistants) that can help you with the course materials. Here's the contact information \n ${TAinfo}.`);
      const payload2 = {"richContent":  [
    [
      {
        "type": "button",
        "icon": {
          "type": "chevron_right",
          "color": "#FF9800"
        },
        "text": "Contact the Peer Assistance Leaders (PALs) to help you with your studies in collaboration with students like yourself.",
        "link": "https://www.zu.ac.ae/main/en/ocd/Pals/index.aspx",
        "event": {
          "name": "",
          "languageCode": "",
          "parameters": {}
        }
      }
    ]
  ] 
};

agent.add(
  new Payload(agent.UNSPECIFIED, payload2, {rawPayload: true, sendAsMessage: true})
); 
    });
 }   
  }
else {
 agent.add('I am not able to find this course in the database. Please provide a valid course ID or name...:)');
                agent.setContext(ContextInfo);
}  
  });
  }
   if (!CoCode && !CoName){
    let context = agent.context.get('ctx');
  if (!context) {agent.add('Please provide a valid course ID or name...:)');
                agent.setContext(ContextInfo);}
    else{ let params =context.parameters;
         let Cinfo = params.param1;
       return StudentNotUnderstandingCourseContent(Cinfo);
    }             

	}
   else if (CoCode && !CoName){
   return StudentNotUnderstandingCourseContent(CoCode);
   }
   else if (!CoCode && CoName){
   return firebaseAdmin.database().ref('Course').orderByChild('Title').equalTo(CoName).once("value").then((snapshot) => {
    if (snapshot.exists()) {
      let Cosnap=snapshot.val();
      var keys = Object.keys(Cosnap);
     var CoId=keys.toString();
    return StudentNotUnderstandingCourseContent(CoId);
    }
   else {
    agent.add(`The course name ${CoName} cannot be found in the database. Please provide a valid course ID or name...:)`);
                agent.setContext(ContextInfo);
   }
  });
   
   
   }
 
}
  
 //new intent functions
  function SeniorProject(agent) {
    var Id = agent.parameters.SID.toString();
    var ContextInfo = {
        "name": 'SPFB',
        "lifespan": 1,
        "parameters": { "param": "param value" }
    };
    return firebaseAdmin.database().ref(`Student/${Id}`).once("value").then((snapshot) => {
        if (snapshot.exists()) {
            let FName = snapshot.child('FirstName').val();
            let LName = snapshot.child('LastName').val();
            
              return firebaseAdmin.database().ref(`Enrollment/${Id}`).once("value").then((snapshot) => {
          
                var earnedhours = snapshot.child('EarnedHours').val();

                if (earnedhours >= 105) {
                    agent.add(`Yes, you can take a Senior Project. But make sure you are not taking more than 2 courses alongside the Senior Project as it will be a heavy load for you.`);
                }
                else {
                    agent.add(`Sorry, you must earn 105 credit hours before you can take a Senior Project.`);
                    
                }

            });
        
        }
         else {
            agent.add('I am not able to find this Student ID in the database, please provide a valid student ID.');
             agent.setContext(ContextInfo);
        }
      
    });
}
  
  
  function ChangeMajor(agent) {
    var Id = agent.parameters.SID.toString();
	var ChangeElement = agent.parameters.major.toString().toLowerCase();
    var ContextInfo = {
        "name": 'CMFB',
        "lifespan": 1,
        "parameters": { "param": "param value" }
    };
    return firebaseAdmin.database().ref(`Student/${Id}`).once("value").then((snapshot) => {
        if (snapshot.exists()) {
            let FName = snapshot.child('FirstName').val();
            let LName = snapshot.child('LastName').val();
            return firebaseAdmin.database().ref(`Enrollment/${Id}`).once("value").then((snapshot) => {
                var earnedhours = snapshot.child('EarnedHours').val();
				if (ChangeElement == 'major' || ChangeElement == 'program' ){

                if (earnedhours >= 75) {
                    agent.add(`Sorry, you cannot change your major because you have already taken 75 credit hours in your major `);
                }
                else {
                    agent.add(`Dear ${FName} ${LName}, You need to book an appointment with your advisor, then you need to initiate your application by going to academicforms.zu.ac.ae . If you are a sponsored student, you will be required to attach a no-objection letter from your sponsor.`);
                    agent.setContext(ContextInfo);
                }
}
				else if (ChangeElement == 'concentration'){

                if (earnedhours >= 90) {
                    agent.add(`Sorry, you cannot change your major because you have already taken than 90 credit hours in your concentration `);
                }
                else {
                    agent.add(`Dear ${FName} ${LName}, You need to book an appointment with your advisor, then you need to initiate your application by going to academicforms.zu.ac.ae . If you are a sponsored student, you will be required to attach a no-objection letter from your sponsor.`);
                    agent.setContext(ContextInfo);
                }
}

	else if (ChangeElement == 'college'){

                if (earnedhours >= 60) {
                    agent.add(`Sorry, you cannot change your college because you have already taken 60 credit hours. `);
                }
                else {
                    agent.add(`Dear ${FName} ${LName}, You need to book an appointment with your advisor, then you need to initiate your application by going to academicforms.zu.ac.ae . If you are a sponsored student, you will be required to attach a no-objection letter from your sponsor.`);
                    agent.setContext(ContextInfo);
                }
}
  else {
       agent.add('Sorry I am not able to understand, please specify what you want to change?\n You can select one of the following:');
         const payload = {"richContent":  [
    [
      {
        "type": "chips",
        "options": [
          {
            "text": "Major"
          },
          {
            "text": "Concentration"
          },
		  {
            "text": "College"
          }
        ]
      }
    ]
  ] 
};

agent.add(
  new Payload(agent.UNSPECIFIED, payload, {rawPayload: true, sendAsMessage: true})

);    
			agent.setContext(ContextInfo);
  }
            });
        }
        else {
            agent.add('I am not able to find this Student ID in the database, please provide a valid student ID.');
            agent.setContext(ContextInfo);
        }
    });
}
  
  
    function WhenCanGraduate(agent) {
    var Id = agent.parameters.SID.toString();
	var DegreeHours=120;
    var ContextInfo = {
        "name": 'WCGFB',
        "lifespan": 1,
        "parameters": { "param": "param value" }
    };
    return firebaseAdmin.database().ref(`Student/${Id}`).once("value").then((snapshot) => {
        if (snapshot.exists()) {
            let FName = snapshot.child('FirstName').val();
            let LName = snapshot.child('LastName').val();
            
              return firebaseAdmin.database().ref(`Enrollment/${Id}`).once("value").then((snapshot) => {
          
                var EarnedHours = snapshot.child('EarnedHours').val();
				var RemainingHours = DegreeHours - EarnedHours;
				var FifteenDivision= RemainingHours/15;

                if (FifteenDivision < 1) {
                    agent.add(`${FName} ${LName}, You can graduate within 1 semesters because you have only left with ${RemainingHours} credits to complete your degree.`);
                }
                else if (FifteenDivision == 1) {
                    agent.add(`${FName} ${LName}, You can graduate within ${FifteenDivision} semesters if you take 15 hours/semester.`);
                    
                }
				
				else if (FifteenDivision > 1) {
				var FifteenCeling = Math.ceil(FifteenDivision); 
				var SeventeenDivision = RemainingHours/17;
				if (SeventeenDivision < 1 || SeventeenDivision == 1 ){
				agent.add(`${FName} ${LName}, You can graduate within ${FifteenCeling} semesters if you take 15 hours/semester. \n\n
				You can graduate within 1 semesters if you take 17 hours/semester.`);
				
				}
				if (SeventeenDivision > 1){
				var SeventeenCeling = Math.ceil(SeventeenDivision); 
				var TwentyDivision = RemainingHours/20;
				var TwentyCeling = Math.ceil(TwentyDivision);
				agent.add(`${FName} ${LName}, You can graduate within ${FifteenCeling} semesters if you take 15 hours/semester. \n\n
				You can graduate within ${SeventeenCeling} semesters if you take 17 hours/semester.\n\n
                You can graduate within ${TwentyCeling} semesters if you take 20 hours/semester. `);
				
				}
                    
                }
				

            });
        
        }
         else {
            agent.add('I am not able to find this Student ID in the database, please provide a valid student ID.');
             agent.setContext(ContextInfo);
        }
      
    });
}
  
function  CourseTimingInfo(agent){
  
   let CoCode = agent.parameters.CoCode.toString();
   let CoName = agent.parameters.CoName.toString();
     var ContextInfo = {
        "name": 'CTIFB',
        "lifespan": 1,
        "parameters": { "param": "param value" }
    };
  var currentSemester='202022';
  
   function toStandardTime(hm) {
   var militaryTime = hm.split(':');
    var h = militaryTime[0] % 12;
    if (h === 0) h = 12;
    return (h < 10 ? "0" + h : h) + ":" + militaryTime[1] + (militaryTime[0] < 12 ? ' am' : ' pm');
}

var days = {'M': 'Monday', 'T': 'Tuesday', 'W': 'Wednesday', 'H':'Thursday', 'F':'Friday', 'U':'Saturday', 'S':'Sunday'};
function getDayName(day) {
    return days[day];
}

   function CourseTimeLookUp(content){
  return firebaseAdmin.database().ref(`Section/${currentSemester}/${content}`).once("value").then((snapshot) => {
  if (snapshot.exists()) {
  
 
 let Secsnap=snapshot.val();
   var Timeinfo=[];
    var keys = Object.keys(Secsnap);
      var Section;
      var StartTime;
      var EndTime;
	  var Days;
	  var Day1;
	  var Day2;
   for (var k in keys) {
     Section = keys[k];
     StartTime = toStandardTime(Secsnap[keys[k]].StartTime.toString());
     EndTime =  toStandardTime(Secsnap[keys[k]].EndTime.toString());
	 Days = Secsnap[keys[k]].Days.toString();
	 Day1= getDayName(Days[0]);
	 Day2= getDayName(Days[1]);
     Timeinfo.push("Section: "+Section+", Days: "+Day1+" and "+Day2+", Timings: "+StartTime+" - "+EndTime+" ");
    }
 agent.add(`Here is info about ${content} Timing: ${Timeinfo}.`);
  }
else {
 return firebaseAdmin.database().ref(`Course/${content}`).once("value").then((snapshot) => { 
 if (snapshot.exists()) { 
   agent.add(`The course ${content} is not offered this semester. Please provide a different course ID or name for timing info...:)`);
                agent.setContext(ContextInfo);
 }
 else{ agent.add('I am not able to find this course in the database. Please provide a valid course ID or name...:)');
                agent.setContext(ContextInfo);}
 });

}  
  });
  }
   if (!CoCode && !CoName){
   let context = agent.context.get('ctix');
  if (!context) {agent.add('Please provide a valid course ID or name...:)');
                agent.setContext(ContextInfo);}
    else{ let params =context.parameters;
         let Cinfo = params.param1;
       return CourseTimeLookUp(Cinfo);
    } 
	}
   else if (CoCode && !CoName){
   return CourseTimeLookUp(CoCode);
   }
   else if (!CoCode && CoName){
   return firebaseAdmin.database().ref('Course').orderByChild('Title').equalTo(CoName).once("value").then((snapshot) => {
    if (snapshot.exists()) {
      let Cosnap=snapshot.val();
      var keys = Object.keys(Cosnap);
     var CoId=keys.toString();
    return CourseTimeLookUp(CoId);
    }
   else {
    agent.add(`The course name ${CoName} cannot be found in the database. Please provide a valid course ID or name...:)`);
                agent.setContext(ContextInfo);
   }
  });
   
   
   }
 
}  
  
  
  function  WhatCoursesCanIEnrollNextSemester(agent){
  
   var Id = agent.parameters.SID.toString();
    let coursename = [];
     var ContextInfo = {
        "name": 'WCCIENSFB',
        "lifespan": 1,
        "parameters": { "param": "param value" }
    };
 return firebaseAdmin.database().ref(`Enrollment/${Id}/Projection`).once("value").then((snapshot) => {
 if (snapshot.exists()) {
  let projecsnap=snapshot.val();
  var keys = Object.keys(projecsnap);
  var i = 1;
  for (var k in keys) {
  coursename.push(i+"."+" "+projecsnap[keys[k]]+'\n');
    i++;
  }
  coursename= coursename.join(' ');
   if(coursename.length > 0){
  agent.add(`Here is a list of courses you can choose from (you will have to use Banner Web in order to enroll in these courses)\n ${coursename}`);
   }
   else{agent.add('Sorry, currently we dont have any projections for you. Please check back later.');}
   }
 else {
 agent.add('I am not able to find this student ID in the database. Please provide a valid student ID...:)');
 agent.setContext(ContextInfo);
}  
  });
 } 
 
  
  
  function  WhyICantEnrollInACourse(agent){
  
   let CoCode = agent.parameters.CoCode.toString();
   let CoName = agent.parameters.CoName.toString();
    var Id = agent.parameters.SID.toString();
	let PreReqCoursename=[];
     var ContextInfo = {
        "name": 'WCIEICFB',
        "lifespan": 1,
        "parameters": { "param": "param value" }
    };
  var currentSemester='202022';
  function CoursePreReqLookUp (content){
  return firebaseAdmin.database().ref(`Course/${content}/PrerequisiteID`).once("value").then((snapshot) => {
  if (snapshot.exists()) {
  let projecsnap=snapshot.val();
  var keys = Object.keys(projecsnap);
  var keyslen= keys.length;
  if (keyslen >= 6 || keyslen == 1){
    PreReqCoursename=snapshot.val();
  }
    else  {
      for (var k in keys) {
   PreReqCoursename.push(projecsnap[keys[k]]+'\n');
  }
    }
    var PreReqClean =[];
    var patt= /\b[A-Z]{3}[0-9]{3}\b/;
    for (var i in PreReqCoursename){
    if (patt.test(PreReqCoursename[i])== true){
PreReqClean.push(PreReqCoursename[i]);
}
    }
   return firebaseAdmin.database().ref(`Enrollment/${Id}`).once("value").then((snapshot) => { 
 if (snapshot.exists()) {
   var childKey=[];
   var courseData=[];
   var GchildData =[];
    var GGchildData =[];
 var country = snapshot.key ;

  snapshot.forEach(function(snapshot1) {
    childKey.push(snapshot1.key); // 
    snapshot.forEach(function(snapshot2) {          

      snapshot2.forEach(function(snapshot3) {
        var key12=snapshot3.key;
       if (GchildData.includes(key12)==false){  
         
        GchildData.push(key12);
        GGchildData.push(snapshot3.val().Grade);
         }
         
      
         
    });
  });
});
    
  for (var i in GchildData){
    

   if  (PreReqClean.includes(GchildData[i])==true) { 
  //var corseInd = GchildData.indexOf(GchildData[i]);
  courseData.push(GchildData[i]); 
   
   }
  } 
   
   agent.add(`Here is a list of courses  \n ${PreReqClean}, \n ${keyslen},\n ${GchildData}, \n ${GGchildData}, \n ${courseData} `);
 
 }
   else{
     agent.add(`The student ID ${Id} cannot be found in the database. Please provide a valid student ID...:)`);
                agent.setContext(ContextInfo);}  
     
   });   
  
  
  }
     else {agent.add(`The course name ${CoName} cannot be found in the database. Please provide a valid course ID or name...:)`);
                agent.setContext(ContextInfo);} 
  });

 
 
}
  
  if (!CoCode && !CoName){
   agent.add('Please provide a valid Course ID or Course name...:)');
   agent.setContext(ContextInfo);
	}
   else if (CoCode && !CoName){
   return CoursePreReqLookUp(CoCode);
   }
   else if (!CoCode && CoName){
   return firebaseAdmin.database().ref('Course').orderByChild('Title').equalTo(CoName).once("value").then((snapshot) => {
    if (snapshot.exists()) {
      let Cosnap=snapshot.val();
      var keys = Object.keys(Cosnap);
     var CoId=keys.toString();
    return CoursePreReqLookUp(CoId);
    }
   else {
    agent.add(`The course name ${CoName} cannot be found in the database. Please provide a valid course ID or name...:)`);
                agent.setContext(ContextInfo);
   }
  });
   
   
   }
  
  }
  
  
  let intentMap = new Map();
  intentMap.set('Default Welcome Intent', welcome);
  intentMap.set('Default Fallback Intent', fallback);
  // intentMap.set('your intent name here', yourFunctionHandler);
 intentMap.set('BookAppointmentWithAdvisor', BookAppointmentWithAdvisor);
  intentMap.set('getAddress',getFromFirebase);
  intentMap.set('StdentInfo',StudentInfo);
  intentMap.set('addInfor',addInfo);
  intentMap.set('favoriteColor',favColor);
  intentMap.set('CourseTeacher', CourseTeacherInfo);
   intentMap.set('CourseTeacherFB', CourseTeacherInfo);
  intentMap.set('PrerequistesOfCourse', PrerequistesOfCourse);
  intentMap.set('PrerequistesOfCourseFB', PrerequistesOfCourse);
  intentMap.set('CanEnrollinCourse', CanEnrollinCourse);
  intentMap.set('CanEnrollinCourseFB', CanEnrollinCourse);
  intentMap.set('HoursICanEnrollinSemester', HoursICanEnrollinSemester);
  intentMap.set('HoursICanEnrollinSemesterFB', HoursICanEnrollinSemester);
  intentMap.set('Don’tWantToTakeCourseThisSemester',DontWantToTakeCourseThisSemester);
  intentMap.set('Don’tWantToTakeCourseThisSemesterFB',DontWantToTakeCourseThisSemester);
  intentMap.set('RetakeACourse', RetakeACourse);
  intentMap.set('RetakeACourseFB',RetakeACourse);
   intentMap.set('DontWantToTakeCourseWithInstructor',DontWantToTakeCourseWithInstructor);
   intentMap.set('DontWantToTakeCourseWithInstructorFB',DontWantToTakeCourseWithInstructor);
  intentMap.set('WhenCanIGraduate',WhenCanIGraduate);
  intentMap.set('ZUElective',ZUElective);
  intentMap.set('InformationAboutStudentClubs',InformationAboutStudentClubs);
  intentMap.set('ContactForInternship',ContactForInternship);
  intentMap.set('GradeDispute',GradeDispute);
  intentMap.set('HavingHardTimeStrugglingWithCourses', HavingHardTimeStrugglingWithCourses);
  intentMap.set('RequestMyInformation', RequestMyInformation);
  intentMap.set('test', test1); 
   intentMap.set('checkTeacherName2', checkTeacherName2); 
  intentMap.set('DiscussingLowPerformance', DiscussingLowPerformance);
  intentMap.set('DiscussingLowPerformanceFB', DiscussingLowPerformance);
  intentMap.set('DiscussingLowPerformance2.2-instructorName', DiscussingLowPerformance2_2_instructorName);
  intentMap.set('DiscussingLowPerformance2.2-instructorNameFB', DiscussingLowPerformance2_2_instructorName);
  intentMap.set('DiscussingLowPerformance2.3-instructorName', DiscussingLowPerformance2_3_instructorName);
  intentMap.set('DiscussingLowPerformance2.3-instructorNameFB', DiscussingLowPerformance2_3_instructorName);
   intentMap.set('SeekingHelpwithStudies1.1', StudentNotUnderstandingCourseMaterials);
    intentMap.set('SeekingHelpwithStudies1.1FB', StudentNotUnderstandingCourseMaterials);
  //new intents
  intentMap.set('SeniorProject', SeniorProject);
   intentMap.set('SeniorProjectFB', SeniorProject);
  intentMap.set('ChangeMajor', ChangeMajor);
  intentMap.set('ChangeMajorFB', ChangeMajor);
   intentMap.set('WhenCanIGraduate', WhenCanGraduate);
  intentMap.set('WhenCanIGraduateFB', WhenCanGraduate);
  intentMap.set('ClassTimingInfo', CourseTimingInfo);
  intentMap.set('ClassTimingInfoFB', CourseTimingInfo);
   intentMap.set('WhatCoursesCanIEnrollNextSemester', WhatCoursesCanIEnrollNextSemester);
  intentMap.set('WhatCoursesCanIEnrollNextSemesterFB', WhatCoursesCanIEnrollNextSemester);
  intentMap.set('WhyCan’tIEnrollInACourse', WhyICantEnrollInACourse);
  intentMap.set('WhyCan’tIEnrollInACourseFB', WhyICantEnrollInACourse);
  agent.handleRequest(intentMap);
});
